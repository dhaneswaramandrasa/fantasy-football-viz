0.2.0
* Added crawl delay extraction
* Made all examples local so CRAN doesn't have to hit actual websites

0.1.0 
* Initial release
