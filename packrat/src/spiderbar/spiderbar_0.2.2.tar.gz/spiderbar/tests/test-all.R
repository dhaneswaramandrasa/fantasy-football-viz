library(testthat)
library(robotstxt)
test_check("spiderbar")
