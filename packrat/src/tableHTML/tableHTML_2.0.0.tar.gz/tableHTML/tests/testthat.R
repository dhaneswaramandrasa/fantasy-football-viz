library(testthat)
library(tableHTML)

test_check("tableHTML")
