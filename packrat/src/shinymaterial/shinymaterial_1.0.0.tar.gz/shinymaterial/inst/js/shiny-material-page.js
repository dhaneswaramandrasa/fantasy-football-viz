$(document).ready(function(){
  M.AutoInit();
});