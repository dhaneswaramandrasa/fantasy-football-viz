   $(document).ready(function () {

       $('.nav-wrapper').prepend('<a href="#" data-target="slide-out" class="sidenav-trigger show-on-large"><i class="material-icons">menu</i></a>');
   })
