   $(document).ready(function () {
       $('.nav-wrapper').prepend('<a href="#" data-target="slide-out" class="sidenav-trigger"><i class="material-icons">menu</i></a>');
   })
