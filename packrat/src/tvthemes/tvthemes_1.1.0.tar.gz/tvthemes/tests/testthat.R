library(testthat)
library(tvthemes)
library(ggplot2)

test_check("tvthemes")
