## template-depr_fun.r
#' @name <%= fun %>-deprecated
#' @usage <%= gsub("\n", "\n#' ", roxygen2:::wrapString(roxygen2:::function_usage(fun, formals(fun)))) %>
#' @seealso \code{\link{englelab-deprecated}}
#' @keywords internal
