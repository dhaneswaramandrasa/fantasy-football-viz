## template-depr_pkg.r
#' @name englelab-deprecated
#' @section \code{<%= old %>}:
#' For \code{<%= old %>}, use \code{\link{<%= new %>}}.
