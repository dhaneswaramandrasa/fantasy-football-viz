add_rows <- function(x, ...){
  UseMethod("add_rows")
}
format_fun <- function( x, na_string = "", ... ){
  UseMethod("format_fun")
}

