expect_ppd <- function(x) expect_s3_class(x, "ppd")
