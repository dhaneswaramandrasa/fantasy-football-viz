expect_stanreg <- function(x) expect_s3_class(x, "stanreg")
