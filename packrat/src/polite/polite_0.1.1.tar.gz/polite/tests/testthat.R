library(testthat)
library(polite)

test_check("polite")
