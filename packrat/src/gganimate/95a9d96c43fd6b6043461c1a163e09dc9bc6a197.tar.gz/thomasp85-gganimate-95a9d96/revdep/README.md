# Platform

|field    |value                        |
|:--------|:----------------------------|
|version  |R version 3.6.0 (2019-04-26) |
|os       |macOS Mojave 10.14.6         |
|system   |x86_64, darwin15.6.0         |
|ui       |RStudio                      |
|language |(EN)                         |
|collate  |en_US.UTF-8                  |
|ctype    |en_US.UTF-8                  |
|tz       |Europe/Copenhagen            |
|date     |2019-11-18                   |

# Dependencies

|package   |old   |new        |Δ  |
|:---------|:-----|:----------|:--|
|gganimate |1.0.3 |1.0.3.9000 |*  |

# Revdeps

## Failed to check (1)

|package |version |error |warning |note |
|:-------|:-------|:-----|:-------|:----|
|SSOSVM  |0.2.1   |1     |        |     |

