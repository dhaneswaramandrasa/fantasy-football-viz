# TileMaker 0.2.0

 * Created all new functions using htmlTools. All old functions have been removed (sorry!)

 * Seperated simple box from one that responds to threshold to clarify better hat imputs are required to each

 * file_maker() now doesn't need a filename

 * Added tile_matrix() function to make multiple buttons suitable to quickly take inputs from a dataframe

 * Added multi_box() function to create buttons that contain more than one value and icon.

 * CRAN-ready!

# TileMaker 0.1.0

 * Converting function to stand-alone package
