library(testthat)
library(TileMaker)

test_check("TileMaker")
