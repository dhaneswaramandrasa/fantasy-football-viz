# `tidymodels` 0.0.2

 * Added  `parsnip` and `dials` to the core package list. 
 
 * Package requirements bumped to current versions.


# `tidymodels` 0.0.1

First CRAN version.



