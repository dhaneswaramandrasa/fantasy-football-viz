library(testthat)
library(fplscrapR)

test_check("fplscrapR")
