library("testthat")
library("highcharter")

test_check("highcharter")
