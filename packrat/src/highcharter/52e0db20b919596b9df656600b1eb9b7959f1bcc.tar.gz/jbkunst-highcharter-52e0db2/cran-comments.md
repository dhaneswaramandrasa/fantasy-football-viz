## Resubmission 

- Fix 2 404 urls.
- Fixing duplicated name in vignettes.

Thanks again!
