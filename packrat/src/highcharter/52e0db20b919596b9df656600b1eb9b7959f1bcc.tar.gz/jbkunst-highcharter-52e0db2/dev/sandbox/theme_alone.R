


highcharts_demo() %>% 
  hc_add_theme(hc_theme_alone())

